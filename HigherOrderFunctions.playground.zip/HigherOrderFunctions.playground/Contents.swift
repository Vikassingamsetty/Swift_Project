import UIKit

//Higher Order Functions examples   :   HOF

let names = ["Rohith", "Bala", "sampangi", "harish", "Jack", "Mamba"]

//MARK: for-each
/*
 For-each is used to get the individual value in an array.
“forEach” works like “for in” but the basic difference is, you can’t use break and continue statement to exit from the closure for forEach.
 */
 names.forEach {name in // we can use weak self to avoid memory leak
 print("My nick name is \(name)")
 }
 
 
//MARK: Map
/*
 Map returns a new array which iterates over the given array
 we use it mostly to map values to tableview and collection view
 */
let value = names.map {$0}
print(value,  "-> MAP")


//MARK: Compact Map
/*
 Compact Map return a new array and avoids the nil values which doesn't satisfy the condition
 */
let userName = ["Rohith", nil, "Bala", "sampangi", "harish", "Jack", "Mamba", nil]
let name = userName.compactMap {$0} //avoids nil and provides new array
let values = ["1","2", "*","#", "3"].compactMap{Int($0)}
print("\(name)......\(values), -> COMPACT MAP")

//MARK: Flat Map
/*
 converts 2D array to single array
*/
let nameN = [["Ram","Ramesh","Raju"],["Janu","Mani","Anu"]]
let numbValues = [[1, 5, 2, 10, 6],[2, 7, 4, 10, 15]]

let nam = nameN.flatMap{$0}
let numbValue = numbValues.flatMap{$0}
print("\(nam).....\(numbValue), -> FLAT MAP")


//MARK: Filter
/*
 Filters data based on condition with an new array
 */
let age = [22,23,10,1,33,9,14]
let filteredAge = age.filter{$0<23}
print(filteredAge, "-> FILTER")
 

//MARK: Reduce
/*
 Returns an object with a combined value of all elements.
*/
let purchases = [2256,203,109,91,393,239,2414]
let finalValue = purchases.reduce(0,{$0+$1})
//takes initial value as 0 and addes the sequences of numbers
print(finalValue, "-> REDUCE")


//MARK: Sort
/*
 sort(by:) will sort all elements according to the condition written inside the body of the closure
 */
var coins = [1, 5, 2, 10, 6, 2, 7, 4, 10, 15]
coins.sort { a, b in
    a<b
}
print(coins, "-> SORT BY")


//MARK: Sorted
/*
 sorted(by:) same as sort array but return a new array
 */

var coin = [1, 5, 2, 10, 6, 2, 7, 4, 10, 15]

let sortedarrar = coin.sorted { a, b in
    a<b
}
print("\(coin)....sorted by array \(sortedarrar)")
