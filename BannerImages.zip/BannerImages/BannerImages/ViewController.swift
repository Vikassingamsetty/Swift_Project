//
//  ViewController.swift
//  BannerImages
//
//  Created by Singamsetty Vikas on 11/02/22.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource {

    @IBOutlet weak var CV: UICollectionView!
    
    let clr = [UIColor.red, UIColor.gray, UIColor.green, UIColor.orange]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        CV.delegate = self
        CV.dataSource = self
        CV.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cell")
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = CV.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        cell.backgroundColor = clr[indexPath.item]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: collectionView.frame.size.width/2, height: collectionView.frame.size.width/2)
    }

}

